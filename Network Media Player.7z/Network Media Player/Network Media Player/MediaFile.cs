﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Network_Media_Player
{
    public class MediaFile
    {
        public string FileName { get; set; }
        public string Path { get; set; }
    }
}
