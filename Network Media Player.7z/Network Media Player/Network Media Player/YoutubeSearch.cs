﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using YoutubeSearch;
using System.Net;
using System.IO;

namespace Network_Media_Player
{
    public partial class YoutubeSearch : Form
    {
        int pageNumber = 1;
        public YoutubeSearch()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e) //serach video on youtube
        {
            DataGridView data = new DataGridView();
            //Encoding utf8 = Encoding.UTF8;
            VideoSearch items = new VideoSearch();
            List<Video> list = new List<Video>();
            try
            {
                foreach (var item in items.SearchQuery(textBox1.Text, pageNumber))
                {
                    //STYLE
                    var style = new DataGridViewCellStyle();
                    style.Font = new System.Drawing.Font("Times New Roman", 10F,
                                                         System.Drawing.FontStyle.Regular,
                                                         System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    dataGridView1.Columns[1].HeaderCell.Style = style;
                    //dataGridView1.Columns[1].ValueType.IsValueType;
                    dataGridView1.Columns[1].ValueType = typeof(string);
                    //STYLE
                    Video video = new Video();
                    //byte[] result = Encoding.UTF8.GetBytes((item.Title).ToString());
                    //string[] lines = File.ReadAllLines(video.Title, Encoding.Default);
                    video.Title = item.Title; 
                    //byte[] result = Encoding.UTF8.GetBytes((item.Title).ToString());
                    //byte[] utf8Bytes = utf8.GetBytes(item.Title);
                    video.Author = item.Author;
                    video.Url = item.Url;
                    byte[] imageBytes = new WebClient().DownloadData(item.Thumbnail);
                    using (MemoryStream ms = new MemoryStream(imageBytes))
                    {
                        video.Thumbnail = Image.FromStream(ms);
                    }
                    list.Add(video);
                }
                videoBindingSource.DataSource = list;
            }
            catch
            {
                MessageBox.Show("Error!!! Check query or internet connection");
                //this.Close();
            }
           
        }

        private void button2_Click(object sender, EventArgs e)//previous page
        {
            if (pageNumber > 1 & dataGridView1 != null)
            {
                pageNumber--;
                button1_Click(null, null);
            }
            else 
            {
                MessageBox.Show("ERROR!!! IT IS FIRST PAGE!");
            }
        }

        private void button3_Click(object sender, EventArgs e)//next page
        {

                pageNumber++;
                button1.PerformClick();
        }

        private void button4_Click(object sender, EventArgs e)//open mediaplayer
        {
            Form1 f = new Form1();
            f.Show();
        }

        #region hints
        ToolTip t1 = new ToolTip();
        ToolTip t2 = new ToolTip();
        ToolTip t3 = new ToolTip();
        ToolTip t4 = new ToolTip();
        ToolTip t5 = new ToolTip();
        ToolTip t6 = new ToolTip();
        private void textBox1_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Input title video here: ", textBox1);
        }
        private void button1_MouseHover(object sender, EventArgs e)
        {
            t2.Show("Press fo search videos on youtube", button1);
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            t3.Show("Open mediaplayer", button4);
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            t4.Show("Previous page on youtube search", button2);
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            t5.Show("Next page on youtube search", button3);
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            t6.Show("Open youtube player", button5);
        }

        #endregion

        private void button5_Click(object sender, EventArgs e)// open youtube player
        {
            YoutubePlayer yp = new YoutubePlayer();
            yp.Show();
        }


    }
}
