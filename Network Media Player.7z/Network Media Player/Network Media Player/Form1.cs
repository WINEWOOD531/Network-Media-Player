﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WMPLib;
using AxWMPLib;
using System.Diagnostics;

namespace Network_Media_Player
{
    
    public partial class Form1 : Form
    {
        int i = 0;
        string[] files1, paths;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//open file or files
        {
            //робочий код+2строчки в Form1_Load
            //using (OpenFileDialog ofd = new OpenFileDialog() { Multiselect = true, Filter = "WMV|*.wmv|WAV|*.wav|MP3|*.mp3|MP4|*.mp4|MKV|*.mkv|AVI|*.avi" })
            //{
            //    if (ofd.ShowDialog() == DialogResult.OK)
            //    {
            //        List<MediaFile> files = new List<MediaFile>();
            //        foreach (string fileName in ofd.FileNames)
            //        {
            //            FileInfo fi = new FileInfo(fileName);
            //            files.Add(new MediaFile() { FileName = Path.GetFileNameWithoutExtension(fi.FullName), Path = fi.FullName });
            //        }
            //        listBox1.DataSource = files;
            //    }
            //}

            String userName = System.Environment.UserName;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = @"C:\Users\" + userName + "\\Documents\\MyMusic";
            ofd.Filter = "(mp3,wav,mp4,mov,wmv,mpg,avi,3gp,flv)|*.mp3;*.wav;*.mp4;*.3gp;*.avi;*.mov;*.flv;*.wmv;*.mpg;|all files|*.*";
            ofd.Multiselect = true;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                files1 = ofd.SafeFileNames;
                paths = ofd.FileNames;
                for (int i = 0; i < files1.Length; i++)
                {
                    listBox1.Items.Add(files1[i]);
                }
            }
        }
        #region youtube

        private void button5_Click(object sender, EventArgs e)//youtube play button
        {
            //if (!string.IsNullOrEmpty(txtUrl.Text))
            //{
            //    //string url = textBox1.Text.Replace("watch?v=","v/");
            //    //axShockwaveFlash1.Movie = url;
            //    //axShockwaveFlash1.Play();
            //    string html = "<html><head>";
            //    html += "<meta content='IE=Edge' http-equiv='X-UA-Compatible'/>";
            //    html += "<iframe id='video' src= 'https://www.youtube.com/embed/{0}' width='755' height='340' frameborder='0' allowfullscreen></iframe>";
            //    html += "</body></html>";
            //    this.webBrowser1.DocumentText = string.Format(html, txtUrl.Text.Split('=')[1]);
            //}
        }

        private void button6_Click(object sender, EventArgs e)//youtube search form load
        {
             YoutubeSearch ys = new YoutubeSearch();
            ys.Show();
        }
        #endregion
        private void button7_Click(object sender, EventArgs e)//full screen
        {
            //if (axWindowsMediaPlayer1.URL.Length>0)
            //{
            //    axWindowsMediaPlayer1.fullScreen = true;
            //}
            if (axWindowsMediaPlayer1.playState==WMPLib.WMPPlayState.wmppsPlaying)
            {
                axWindowsMediaPlayer1.fullScreen = true;
            }
            else 
            {
                axWindowsMediaPlayer1.fullScreen = false;
            }

        }
       
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //робочий код+2строчки в Form1_Load
            //MediaFile file = listBox1.SelectedItem as MediaFile;
            //if (file != null)
            //{
            //    axWindowsMediaPlayer1.URL = file.Path;
            //    axWindowsMediaPlayer1.Ctlcontrols.play();
            //}
            axWindowsMediaPlayer1.URL = paths[listBox1.SelectedIndex];
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //listBox1.ValueMember = "Path";
            //listBox1.DisplayMember = "FileName";
            axWindowsMediaPlayer1.uiMode = "none";
        }

        private void button10_Click(object sender, EventArgs e)//play
        {
            if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                //listBox1.SelectedIndex = 0;
                button10.BackgroundImage = Properties.Resources._1577;
                axWindowsMediaPlayer1.Ctlcontrols.pause();
            }
            else if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPaused)
            {
                //listBox1.SelectedIndex = 0;
                button10.BackgroundImage = Properties.Resources._1576;
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
            else if (listBox1.SelectedIndex > 0)
            {
                axWindowsMediaPlayer1.URL = paths[listBox1.SelectedIndex];
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
            else if (listBox1.SelectedIndex == 0)
            {
                //listBox1.SelectedIndex = 0;
                axWindowsMediaPlayer1.Ctlcontrols.play();
            }
        }

        private void button13_Click(object sender, EventArgs e)//stop
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
        }

        private void button12_Click(object sender, EventArgs e) //prev
        {
            if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                if (listBox1.SelectedIndex ==0)
                {
                    listBox1.SelectedIndex = 0;
                    listBox1.Update();
                }

                else
                {
                    axWindowsMediaPlayer1.Ctlcontrols.previous();
                    listBox1.SelectedIndex -= 1;
                    listBox1.Update();
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)//next
        {
            if (axWindowsMediaPlayer1.playState==WMPLib.WMPPlayState.wmppsPlaying)
            {
                if (listBox1.SelectedIndex<(listBox1.Items.Count-1))
                {
                    axWindowsMediaPlayer1.Ctlcontrols.next();
                    listBox1.SelectedIndex += 1;
                    listBox1.Update();
                }

                else
                {
                    listBox1.SelectedIndex = 0;
                    listBox1.Update();
                }
            }
            
        } 

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            int rate = 100*(trackBar1.Value-10);
            axWindowsMediaPlayer1.settings.volume = trackBar1.Value;
            if (trackBar1.Value <= 0)
            {
                MuteVolumeBtn.BackgroundImage = Properties.Resources.anim_0451;
                axWindowsMediaPlayer1.settings.volume = 0;
            }
            else {
                MuteVolumeBtn.BackgroundImage = Properties.Resources.anim_0452;
                 }
        } // volume level

        private void MuteVolumeBtn_Click(object sender, EventArgs e)//MUTE
        {
            if (axWindowsMediaPlayer1.settings.volume==100)
            {
                MuteVolumeBtn.BackgroundImage = Properties.Resources.anim_0451;
                axWindowsMediaPlayer1.settings.volume = 0;
                trackBar1.Value = 0;
            }
            else
            {
                MuteVolumeBtn.BackgroundImage = Properties.Resources.anim_0452;
                axWindowsMediaPlayer1.settings.volume = 100;
                trackBar1.Value = 100;
            }
        }

        private void button14_Click(object sender, EventArgs e)//fast forvard
        {
            axWindowsMediaPlayer1.Ctlcontrols.fastForward();
        }

        private void button15_Click(object sender, EventArgs e)//fast reverse
        {
            axWindowsMediaPlayer1.Ctlcontrols.fastReverse();
        }

        private void button9_Click(object sender, EventArgs e)//clear playlist
        {
            if (listBox1.SelectedIndex == 0 || axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {

                listBox1.Items.Clear();
                axWindowsMediaPlayer1.Ctlcontrols.stop();
                listBox1.Update();
            }
            else 
            {
                Environment.Exit(0);
            }
        }

        private void listBox1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            foreach (string file in files)
            {
                //add To Media PLayer
                //Play the files 


            }
        }

        private void listBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop, false) == true)
            {
                e.Effect = DragDropEffects.All;
            }
        }
        #region
        private void button2_Click(object sender, EventArgs e)//full screen youtube
        {
            //webBrowser1.;
            //ActiveForm.SendKeys("{F11}");
            //SendKeys.Send("{F11}");
            WindowState = FormWindowState.Maximized;
        }

        private void button3_Click(object sender, EventArgs e)// show youtube player
        {
            YoutubePlayer yp = new YoutubePlayer();
            yp.ShowDialog();
        }
        #endregion
        private void button8_Click(object sender, EventArgs e)//hide or show playlist
        {
            if (i == 0)
            {
                listBox1.Show();
                label6.Text = "Hide playlist";
                i = 1;
                axWindowsMediaPlayer1.Width = 469;


            }
            else if (i == 1)
            {
                listBox1.Hide();
                label6.Text = "Show playlist";
                i = 0;
                axWindowsMediaPlayer1.Width = 884;
            }
        }

        #region hints
        ToolTip t1 = new ToolTip();
        ToolTip t2 = new ToolTip();
        ToolTip t3 = new ToolTip();
        ToolTip t4 = new ToolTip();
        ToolTip t5 = new ToolTip();
        ToolTip t6 = new ToolTip();
        ToolTip t7 = new ToolTip();
        ToolTip t8 = new ToolTip();
        ToolTip t9 = new ToolTip();
        ToolTip t10 = new ToolTip();
        ToolTip t11 = new ToolTip();
        ToolTip t12 = new ToolTip();
        ToolTip t13 = new ToolTip();
        ToolTip t14 = new ToolTip();



        private void button6_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Search video on youtube", button6);
        }

        private void button8_MouseHover(object sender, EventArgs e)
        {
            t3.Show("Hide playlist", button8);
        }

        private void button7_MouseHover(object sender, EventArgs e)
        {
            t4.Show("Full screen mediaplayer", button7);
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            t5.Show("Open file from disc", button1);
        }

        private void button9_MouseHover(object sender, EventArgs e)
        {
            t6.Show("Delete all songs from playlist", button9);
        }

        private void trackBar1_MouseHover(object sender, EventArgs e)
        {
            t7.Show("Control volume level on mediaplayer", trackBar1);
        }

        private void MuteVolumeBtn_MouseHover(object sender, EventArgs e)
        {
            t8.Show("ON/OF SOUND", MuteVolumeBtn);
        }

        private void button14_MouseHover(object sender, EventArgs e)
        {
            t9.Show("Fast forvard music", button14);
        }

        private void button11_MouseHover(object sender, EventArgs e)
        {
            t10.Show("Next sound in playlist", button11);
        }

        private void button13_MouseHover(object sender, EventArgs e)
        {
            t11.Show("Stop music", button13);
        }

        private void button10_MouseHover(object sender, EventArgs e)
        {
            t12.Show("Play/Pause music", button10);
        }

        private void button12_MouseHover(object sender, EventArgs e)
        {
            t13.Show("Prev sound in playlist", button11);
        }

        private void button15_MouseHover(object sender, EventArgs e)
        {
            t14.Show("Reverse forvard music", button15);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            FeedBack form = new FeedBack();
            form.ShowDialog();
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            t2.Show("Open youtube player", button3);
        }

        #endregion

    }
}
