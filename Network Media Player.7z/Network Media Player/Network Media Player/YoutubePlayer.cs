﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Network_Media_Player
{
    public partial class YoutubePlayer : Form
    {
        //Для кнопки Full Screen: this.WindowState = FormWindowState.Minimized;
        public YoutubePlayer()
        {
            InitializeComponent();

        }

        private void button5_Click(object sender, EventArgs e) //PLAY YOUTUBE VIDEOS
        {
            string a;
            //if (txtUrl.Text != String.Empty)
            //{
            try
            {
                string html = "<html><head>";
                html += "<meta content='IE=Edge' http-equiv='X-UA-Compatible'/>";
                html += "<iframe id='video' src= 'https://www.youtube.com/embed/{0}/controls=1&autohide=2' width='755' height='340' frameborder='0' allowfullscreen></iframe>";
                html += "</body></html>";
                this.webBrowser1.DocumentText = string.Format(html, txtUrl.Text.Split('=')[1]);
            }
            catch
            {
                MessageBox.Show("ERROR!!! EMPTY OR INCORRECT VALUE");
            }
                //}
                //else { 

            //    MessageBox.Show("ERROR!!! EMPTY VALUE");
            //    //this.Close();
            //     }

            //string html = "<html><head>";
            //html += "<meta content='IE=Edge' http-equiv='X-UA-Compatible'/>";
            //html += "<iframe id='video' src= 'https://www.youtube.com/embed/{0}/controls=1&autohide=2' width='755' height='340' frameborder='0' allowfullscreen></iframe>";
            //html += "</body></html>";
            //this.webBrowser1.DocumentText = string.Format(html, txtUrl.Text.Split('=')[1]);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            //WindowState = FormWindowState.Maximized;
        } //open mediaplayer

        private void button1_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            this.Close();
        }// close application

        private void button4_Click(object sender, EventArgs e)
        {
            YoutubeSearch ys = new YoutubeSearch();
            ys.Show();
        }// show youtube search

        private void button6_Click(object sender, EventArgs e)
        {
            //this.WindowState = FormWindowState.Minimized;
            WindowState = FormWindowState.Maximized;

        } //max size window

        //private void button3_Click(object sender, EventArgs e)
        //{
        //    this.WindowState = FormWindowState.Minimized;
        //}

        //private void ButtonName_MouseHover(object sender, EventArgs e)
        //{
        //    string c = "Hide application";
        //    System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();
        //    ToolTip1.SetToolTip(this.button3, c);//this.button1.Text);
        //}
        #region hints
        ToolTip t1 = new ToolTip();
        ToolTip t2 = new ToolTip();
        ToolTip t3 = new ToolTip();
        ToolTip t4 = new ToolTip();
        ToolTip t5 = new ToolTip();
        ToolTip t6 = new ToolTip();
        ToolTip t7 = new ToolTip();
        ToolTip t8 = new ToolTip();
        private void button3_MouseHover(object sender, EventArgs e)
        {
            t1.Show("Hide application", button3);
        }

        private void button6_MouseHover(object sender, EventArgs e)
        {
            t2.Show("Full screen application", button3);
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            t3.Show("Play youtube video", button5);
        }

        private void button4_MouseHover(object sender, EventArgs e)
        {
            t4.Show("Search video on youtube", button4);
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            t5.Show("Close this window", button1);
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            t6.Show("Open mediaplayer", button2);
        }

        private void button7_MouseHover(object sender, EventArgs e)
        {
            t7.Show("Clear URL text", button7);
        }

        private void txtUrl_MouseHover(object sender, EventArgs e)
        {
            t8.Show("Paste youtube url here: ", txtUrl);
        }
        #endregion

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }   //hide application on tasks panel

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
        } //Show mediaplayer from youtube mediaplayer form

        private void button7_Click(object sender, EventArgs e) //Clear URL text youtube mediaplayer
        {
            txtUrl.Clear();
        }
    }
}
