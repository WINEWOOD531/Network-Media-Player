﻿using System;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace Network_Media_Player
{
    public partial class FeedBack : Form
    {
        public FeedBack()
        {
            InitializeComponent();
        }

        private void FeedBack_Load(object sender, EventArgs e)
        {

        }

        private void SendMsg(string name, string msg)
        {
            // отправитель - устанавливаем адрес и отображаемое в письме имя
            MailAddress from = new MailAddress("networkmediaplayerfeedback@gmail.com", name);
            // кому отправляем
            MailAddress to = new MailAddress("networkmediaplayerfeedback@gmail.com");
            // создаем объект сообщения
            MailMessage m = new MailMessage(from, to);
            // тема письма
            m.Subject = "Обратная связь";
            // текст письма
            m.Body = $"<h2>{msg}</h2>";
            // письмо представляет код html
            m.IsBodyHtml = true;
            // адрес smtp-сервера и порт, с которого будем отправлять письмо
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
            // логин и пароль
            smtp.Credentials = new NetworkCredential("networkmediaplayerfeedback@gmail.com", "NOKIA2710");
            smtp.EnableSsl = true;
            smtp.Send(m);
            Console.Read();
            MessageBox.Show("Сообщение отправлено!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!tb_name.Text.Equals("") || !tb_message.Text.Equals(""))
            {
                SendMsg(tb_name.Text, tb_message.Text);
                Close();
            }
        }
    }
}
